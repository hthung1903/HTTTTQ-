# P1/ Formulario Plano Moderno con Menú Animado (Contraer-Expandir Menú), One Window, Versión Base/ C#, WinForm (Beta)
<H2>Tutorial:</h2>
<h3>Blog:</h3>
https://rjcodeadvance.com/disenar-interfaz-de-usuario-modernista-only-window-con-c-version-base/
<h3>YouTube:</h3>
https://www.youtube.com/watch?v=y1jftnTaTXU

<img class="fit-picture"
     src="https://lh3.googleusercontent.com/x1Sn_p7JvL-7gDFSvwmCGnPn_ovkrCR8Hs2Ywb_keEzGjibtwR7sWw7-YqIj4MPi93-0a81ldAJUmUtFZeaOZkPU7mCvHLxA3PvK3gAbm6xkIUWHMQCIBvAP9UIX5Ni3x_4ALKG64g=w1313-h739-no"
     alt="Grapefruit slice atop a pile of other slices" />
